# Королевство Ардория — Android-проект

Это Android Studio-проект-оболочка для браузерной игры из архива. Он открывает `index.html` внутри полноэкранного Android WebView, сохраняет localStorage и использует безопасный локальный адрес через AndroidX WebKit AssetLoader, чтобы работали JavaScript ES-модули с относительными импортами.

## Как собрать APK

1. Установите Android Studio на компьютер.
2. Распакуйте этот ZIP.
3. Откройте в Android Studio папку `ArdoriaAndroid` (именно корень, где лежат `settings.gradle.kts`).
4. Дождитесь Gradle Sync. Нужны Android SDK Platform 35 и JDK 17.
5. Выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

## Важно

- Проект настроен на Android 6.0+ (API 23), включая Android 15/16 при наличии актуального системного WebView.
- Для загрузки Three.js игра обращается к `cdn.jsdelivr.net`, поэтому при первом запуске нужен интернет.
- Игра запускается в альбомной ориентации и полноэкранном режиме.
- Это проект для сборки, не готовый APK. В текущей среде Android SDK/Gradle не установлены, поэтому APK здесь не был скомпилирован и протестирован на устройстве.

## Сборка через GitHub Actions (если нет компьютера с Android Studio)

В проект добавлен workflow `.github/workflows/build-apk.yml`. После загрузки проекта в GitHub:
1. Откройте репозиторий → вкладка **Actions**.
2. Выберите **Build Android APK** → **Run workflow**.
3. После завершения откройте запуск workflow и скачайте artifact `Korolevstvo-Ardoria-debug-apk`.

Для этого нужен GitHub-репозиторий; сам workflow не загружает проект на GitHub автоматически.
