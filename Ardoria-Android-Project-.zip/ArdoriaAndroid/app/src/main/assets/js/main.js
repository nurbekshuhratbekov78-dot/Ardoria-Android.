// Точка входа: сцена, свет, небо, цикл день–ночь, погода, игровой цикл, пауза.
import * as THREE from 'three';
import { G } from './game.js';
import { world } from './world.js';
import { initPlayer, updatePlayer, isTouch, lockPointer, unlockPointer } from './player.js';
import { audio } from './audio.js';
import { initMedieval } from './medieval.js';

const $ = id => document.getElementById(id);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
window.G = G; // удобно для отладки в консоли

// Палитра неба по времени суток: [t, верх, горизонт]
const SKY = [
  [0.00, 0x040814, 0x0a1230], [0.20, 0x070d24, 0x18204a], [0.25, 0x3b4f8f, 0xf2a46b],
  [0.32, 0x4f8fe0, 0xb9dcff], [0.50, 0x3f86e6, 0xb5dcff], [0.68, 0x4f8fe0, 0xb9dcff],
  [0.75, 0x3a477f, 0xf08a55], [0.80, 0x0f1633, 0x2a2a55], [0.90, 0x050a1c, 0x0b1230],
  [1.00, 0x040814, 0x0a1230]
];
const cTop = new THREE.Color(), cHor = new THREE.Color(), cTmp = new THREE.Color(), cGrey = new THREE.Color();

let renderer, scene, camera, sun, moon, hemi, skyDome, sunDisc, moonDisc, stars, rain;
const RAIN_N = 1200;
let rainData = null;

async function boot() {
  const status = $('loadStatus');
  const step = async t => { status.textContent = t; await new Promise(r => setTimeout(r, 40)); };

  await step('Запускаем движок…');
  renderer = new THREE.WebGLRenderer({ canvas: $('game'), antialias: !isTouch, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.setSize(innerWidth, innerHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;

  scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0x9fc8ff, 60, 320);
  camera = new THREE.PerspectiveCamera(65, innerWidth / innerHeight, 0.1, 1000);
  G.scene = scene; G.camera = camera; G.renderer = renderer;

  // Свет: солнце (с тенями), луна, небесный полусвет
  sun = new THREE.DirectionalLight(0xfff2d8, 1.2);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  const sc = sun.shadow.camera; sc.left = -45; sc.right = 45; sc.top = 45; sc.bottom = -45; sc.near = 1; sc.far = 220;
  sun.shadow.bias = -0.0006;
  moon = new THREE.DirectionalLight(0x8aa6ff, 0.3);
  hemi = new THREE.HemisphereLight(0xb5dcff, 0x3a3a30, 0.6);
  scene.add(sun, sun.target, moon, hemi);

  buildSky();
  buildRain();

  await world.build(scene, step);
  await step('Создаём героя…');
  initPlayer(scene, camera);
  initMedieval(scene);
  world.update(0, G.player.pos.x, G.player.pos.z);

  addEventListener('resize', () => {
    renderer.setSize(innerWidth, innerHeight);
    camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  });

  setupMenus();
  applyTime(0);
  updateHud();
  status.textContent = 'Мир готов.';
  $('startBtn').disabled = false;
  $('controlsHint').innerHTML = isTouch
    ? 'Левый палец — ходьба, правая часть экрана — поворот камеры,<br>два пальца — приближение. Кнопки справа: ⚔ удар, 🛡 блок, ⬆ прыжок, 🏃 бег, ✋ действие.'
    : 'WASD — ходьба, Shift — бег, Пробел — прыжок, мышь — камера, колесо — зум,<br>ЛКМ — удар, ПКМ — блок, E — действие, I — инвентарь, M — карта, Tab — квесты, Esc — пауза.';

  requestAnimationFrame(frame);
}

// ---------- Небо ----------
function buildSky() {
  const mat = new THREE.ShaderMaterial({
    uniforms: { top: { value: new THREE.Color() }, horizon: { value: new THREE.Color() } },
    vertexShader: 'varying float vH; void main(){ vH = normalize(position).y; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
    fragmentShader: 'uniform vec3 top; uniform vec3 horizon; varying float vH; void main(){ float h = clamp(vH, 0.0, 1.0); gl_FragColor = vec4(mix(horizon, top, pow(h, 0.55)), 1.0);\n#include <colorspace_fragment>\n}',
    side: THREE.BackSide, depthWrite: false, fog: false
  });
  skyDome = new THREE.Mesh(new THREE.SphereGeometry(500, 24, 14), mat);
  skyDome.frustumCulled = false; skyDome.renderOrder = -10;
  scene.add(skyDome);

  sunDisc = new THREE.Mesh(new THREE.SphereGeometry(18, 12, 8), new THREE.MeshBasicMaterial({ color: 0xfff1b0, fog: false }));
  moonDisc = new THREE.Mesh(new THREE.SphereGeometry(12, 12, 8), new THREE.MeshBasicMaterial({ color: 0xdfe6ff, fog: false }));
  sunDisc.frustumCulled = moonDisc.frustumCulled = false;
  scene.add(sunDisc, moonDisc);

  const pts = new Float32Array(450 * 3);
  for (let i = 0; i < 450; i++) {
    const a = Math.random() * 6.283, e = 0.08 + Math.random() * 1.3, r = 480;
    pts[i * 3] = Math.cos(a) * Math.cos(e) * r; pts[i * 3 + 1] = Math.sin(e) * r; pts[i * 3 + 2] = Math.sin(a) * Math.cos(e) * r;
  }
  const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.BufferAttribute(pts, 3));
  stars = new THREE.Points(sg, new THREE.PointsMaterial({ color: 0xffffff, size: 2, sizeAttenuation: false, transparent: true, opacity: 0, depthWrite: false, fog: false }));
  stars.frustumCulled = false;
  scene.add(stars);
}

// ---------- Дождь (ограниченное число капель) ----------
function buildRain() {
  rainData = new Float32Array(RAIN_N * 3);
  for (let i = 0; i < RAIN_N; i++) {
    rainData[i * 3] = (Math.random() - 0.5) * 50; rainData[i * 3 + 1] = Math.random() * 30; rainData[i * 3 + 2] = (Math.random() - 0.5) * 50;
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(RAIN_N * 6), 3));
  rain = new THREE.LineSegments(g, new THREE.LineBasicMaterial({ color: 0x9fb4c8, transparent: true, opacity: 0.5, fog: false }));
  rain.frustumCulled = false; rain.visible = false;
  scene.add(rain);
}
function updateRain(dt) {
  const W = G.weather;
  rain.visible = W.rain > 0.03;
  if (!rain.visible) return;
  const p = rain.geometry.attributes.position.array, c = camera.position;
  const n = Math.floor(RAIN_N * W.rain);
  for (let i = 0; i < RAIN_N; i++) {
    if (i < n) {
      rainData[i * 3 + 1] -= 28 * dt;
      if (rainData[i * 3 + 1] < -2) { rainData[i * 3 + 1] += 30; rainData[i * 3] = (Math.random() - 0.5) * 50; rainData[i * 3 + 2] = (Math.random() - 0.5) * 50; }
      const x = c.x + rainData[i * 3], y = c.y - 4 + rainData[i * 3 + 1], z = c.z + rainData[i * 3 + 2];
      p[i * 6] = x; p[i * 6 + 1] = y; p[i * 6 + 2] = z;
      p[i * 6 + 3] = x + 0.05; p[i * 6 + 4] = y + 0.6; p[i * 6 + 5] = z + 0.02;
    } else { p[i * 6 + 1] = p[i * 6 + 4] = -999; }
  }
  rain.geometry.attributes.position.needsUpdate = true;
}

// ---------- Время суток, свет, туман ----------
function palette(t) {
  for (let i = 0; i < SKY.length - 1; i++) {
    const a = SKY[i], b = SKY[i + 1];
    if (t >= a[0] && t <= b[0]) {
      const k = (t - a[0]) / (b[0] - a[0]);
      cTop.setHex(a[1]); cTmp.setHex(b[1]); cTop.lerp(cTmp, k);
      cHor.setHex(a[2]); cTmp.setHex(b[2]); cHor.lerp(cTmp, k);
      return;
    }
  }
}
const sunDir = new THREE.Vector3(), moonDir = new THREE.Vector3();
function applyTime(dt) {
  const T = G.time, W = G.weather;
  T.t = (T.t + dt / T.dayLength) % 1;
  const a = (T.t - 0.25) * Math.PI * 2;
  T.sinSun = Math.sin(a);
  T.daylight = smooth(-0.08, 0.22, T.sinSun);
  T.night = 1 - T.daylight;
  sunDir.set(Math.cos(a), Math.sin(a), 0.35).normalize();
  moonDir.copy(sunDir).multiplyScalar(-1);

  palette(T.t);
  const grey = Math.max(W.rain * 0.7, W.fog * 0.85);
  cGrey.setRGB(0.5 * (0.25 + 0.75 * T.daylight), 0.55 * (0.25 + 0.75 * T.daylight), 0.6 * (0.25 + 0.75 * T.daylight));
  cHor.lerp(cGrey, grey); cTop.lerp(cGrey, grey * 0.8);
  skyDome.material.uniforms.top.value.copy(cTop);
  skyDome.material.uniforms.horizon.value.copy(cHor);
  scene.fog.color.copy(cHor);
  renderer.setClearColor(cHor);

  const cp = camera.position;
  skyDome.position.copy(cp);
  sunDisc.position.copy(cp).addScaledVector(sunDir, 450); sunDisc.visible = sunDir.y > -0.08 && W.rain < 0.8;
  moonDisc.position.copy(cp).addScaledVector(moonDir, 450); moonDisc.visible = moonDir.y > -0.08 && W.rain < 0.8;
  stars.position.copy(cp); stars.material.opacity = T.night * (1 - grey);

  // Свет
  const pp = G.player.pos;
  sun.target.position.set(Math.round(pp.x), 0, Math.round(pp.z));
  sun.position.copy(sun.target.position).addScaledVector(sunDir, 90);
  sun.target.updateMatrixWorld();
  sun.castShadow = T.sinSun > 0.06;
  sun.color.setHex(0xff9a55).lerp(cTmp.setHex(0xfff2d8), smooth(0, 0.5, T.sinSun));
  sun.intensity = 1.25 * smooth(-0.02, 0.25, T.sinSun) * (1 - 0.55 * W.rain - 0.3 * W.fog);
  moon.position.copy(pp).addScaledVector(moonDir, 90);
  moon.intensity = 0.4 * T.night;
  hemi.color.copy(cHor).lerp(cTmp.setRGB(1, 1, 1), 0.3);
  hemi.intensity = 0.25 + 0.5 * T.daylight;

  // Туман: дальность зависит от погоды и от леса
  const ff = world.forestFactor(pp.x, pp.z);
  let near = 60 * (1 - W.rain) + 28 * W.rain, far = 320 * (1 - W.rain) + 170 * W.rain;
  near = near * (1 - W.fog) + 8 * W.fog; far = far * (1 - W.fog) + 75 * W.fog;
  near *= 1 - 0.5 * ff; far *= 1 - 0.45 * ff;
  scene.fog.near = near; scene.fog.far = far;
}

// ---------- Погода: ясно / дождь / туман ----------
let weatherTimer = 80;
function updateWeather(dt) {
  const W = G.weather;
  weatherTimer -= dt;
  if (weatherTimer <= 0) {
    weatherTimer = 70 + Math.random() * 90;
    const r = Math.random();
    W.type = r < 0.5 ? 'clear' : r < 0.75 ? 'rain' : 'fog';
    G.emit('weather', W.type);
  }
  const tr = W.type === 'rain' ? 1 : 0, tf = W.type === 'fog' ? 1 : 0, k = Math.min(1, dt * 0.15);
  W.rain += (tr - W.rain) * k; W.fog += (tf - W.fog) * k;
  audio.setRain(W.rain);
  audio.setWind(0.3 + W.rain * 0.5);
}

// ---------- Простой HUD (позже его расширит ui.js) ----------
let hudTimer = 0;
function updateHud() {
  const P = G.player;
  $('hpFill').style.transform = `scaleX(${clamp(P.hp / P.maxHp, 0, 1)})`;
  $('hpText').textContent = `HP ${Math.ceil(P.hp)} / ${P.maxHp}`;
  $('stFill').style.transform = `scaleX(${clamp(P.stamina / P.maxStamina, 0, 1)})`;
  $('stText').textContent = 'Выносливость';
  const need = G.xpForLevel(P.level);
  $('xpFill').style.transform = `scaleX(${clamp(P.xp / need, 0, 1)})`;
  $('xpText').textContent = `Ур. ${P.level}  ·  ${P.xp} / ${need} XP`;
  $('coins').textContent = `🪙 ${P.coins}`;
  const hrs = G.time.t * 24, hh = Math.floor(hrs), mm = Math.floor((hrs - hh) * 60);
  $('clockText').textContent = `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
  $('clockIcon').textContent = G.time.sinSun > -0.05 ? '☀' : '🌙';
  const wt = { clear: '', rain: '🌧 дождь', fog: '🌫 туман' }[G.weather.type];
  $('weatherText').textContent = wt;
}

// ---------- Пауза и меню ----------
let lastEsc = 0;
function setPaused(v) {
  G.flags.paused = v;
  $('pause').classList.toggle('hidden', !v);
  if (v) unlockPointer(); else lockPointer();
}
function setupMenus() {
  $('startBtn').addEventListener('click', async () => {
    audio.init();
    $('start').classList.add('hidden');
    G.flags.started = true;
    try { if (isTouch) await document.documentElement.requestFullscreen?.(); } catch (e) { /* не страшно */ }
    lockPointer();
    G.toast('Добро пожаловать в Ардорию!');
  });
  $('resumeBtn').addEventListener('click', () => setPaused(false));
  $('saveBtn').addEventListener('click', () => G.emit('save'));
  // Esc: если окон интерфейса нет — пауза (повторные события за 250 мс игнорируем)
  G.on('ui:escape', () => {
    const now = performance.now();
    if (now - lastEsc < 250 || !G.flags.started || G.flags.uiOpen || G.flags.dialog) return;
    lastEsc = now;
    setPaused(!G.flags.paused);
  });
  G.on('hurt', () => {
    const f = $('flash'); f.classList.add('on');
    setTimeout(() => f.classList.remove('on'), 120);
  });
}

// ---------- Игровой цикл ----------
let last = performance.now();
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;
  if (!G.flags.paused) {
    G.elapsed += dt;
    updateWeather(dt);
    updatePlayer(dt);
    if (G.flags.started) for (const fn of G._updaters) fn(dt);
    world.update(dt, G.player.pos.x, G.player.pos.z);
    applyTime(dt);
    updateRain(dt);
    hudTimer -= dt;
    if (hudTimer <= 0) { hudTimer = 0.1; updateHud(); }
  }
  renderer.render(scene, camera);
}

boot().catch(err => {
  console.error(err);
  $('loadStatus').textContent = 'Ошибка загрузки: ' + err.message;
});
