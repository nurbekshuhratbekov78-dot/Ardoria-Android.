// Звук через Web Audio API: всё синтезируется осцилляторами и шумом.
let ctx = null, master = null, noiseBuf = null;
let windGain = null, waterGain = null, rainGain = null;

function noiseSource(loop) {
  const s = ctx.createBufferSource();
  s.buffer = noiseBuf; s.loop = loop;
  return s;
}
function env(g, t0, attack, peak, decay) {
  g.gain.cancelScheduledValues(t0);
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(peak, t0 + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + attack + decay);
}

function startWind() {
  const s = noiseSource(true), f = ctx.createBiquadFilter();
  f.type = 'bandpass'; f.frequency.value = 450; f.Q.value = 0.7;
  windGain = ctx.createGain(); windGain.gain.value = 0.05;
  const lfo = ctx.createOscillator(), lg = ctx.createGain();
  lfo.frequency.value = 0.12; lg.gain.value = 0.03;
  lfo.connect(lg); lg.connect(windGain.gain);
  const lfo2 = ctx.createOscillator(), lg2 = ctx.createGain();
  lfo2.frequency.value = 0.07; lg2.gain.value = 250;
  lfo2.connect(lg2); lg2.connect(f.frequency);
  s.connect(f); f.connect(windGain); windGain.connect(master);
  s.start(); lfo.start(); lfo2.start();
}
function startWater() {
  const s = noiseSource(true), f = ctx.createBiquadFilter();
  f.type = 'lowpass'; f.frequency.value = 900;
  waterGain = ctx.createGain(); waterGain.gain.value = 0;
  const lfo = ctx.createOscillator(), lg = ctx.createGain();
  lfo.frequency.value = 0.4; lg.gain.value = 300;
  lfo.connect(lg); lg.connect(f.frequency);
  s.connect(f); f.connect(waterGain); waterGain.connect(master);
  s.start(); lfo.start();
}
function startRain() {
  const s = noiseSource(true), f = ctx.createBiquadFilter();
  f.type = 'highpass'; f.frequency.value = 1800;
  rainGain = ctx.createGain(); rainGain.gain.value = 0;
  s.connect(f); f.connect(rainGain); rainGain.connect(master);
  s.start();
}

export const audio = {
  // Вызывать после первого касания/клика (требование браузера)
  init() {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = 0.6; master.connect(ctx.destination);
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    startWind(); startWater(); startRain();
  },

  // Шаги: тип поверхности зависит от земли под ногами
  step(kind) {
    if (!ctx) return;
    const t = ctx.currentTime, s = noiseSource(false), f = ctx.createBiquadFilter(), g = ctx.createGain();
    if (kind === 'brick' || kind === 'stone' || kind === 'plaza' || kind === 'courtyard') {
      f.type = 'bandpass'; f.frequency.value = 1400 + Math.random() * 600; f.Q.value = 1.2;
    } else if (kind === 'dirt') {
      f.type = 'lowpass'; f.frequency.value = 700 + Math.random() * 200;
    } else {
      f.type = 'lowpass'; f.frequency.value = 450 + Math.random() * 150;
    }
    env(g, t, 0.005, 0.22, 0.09);
    s.connect(f); f.connect(g); g.connect(master);
    s.start(t, Math.random() * 1.5, 0.2);
  },

  // Взмах меча
  sword() {
    if (!ctx) return;
    const t = ctx.currentTime, s = noiseSource(false), f = ctx.createBiquadFilter(), g = ctx.createGain();
    f.type = 'bandpass'; f.Q.value = 2;
    f.frequency.setValueAtTime(600, t); f.frequency.exponentialRampToValueAtTime(3500, t + 0.18);
    env(g, t, 0.03, 0.35, 0.16);
    s.connect(f); f.connect(g); g.connect(master);
    s.start(t, Math.random(), 0.3);
  },

  // Удар по цели
  hit() {
    if (!ctx) return;
    const t = ctx.currentTime, o = ctx.createOscillator(), g = ctx.createGain();
    o.type = 'sine'; o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(50, t + 0.15);
    env(g, t, 0.005, 0.5, 0.16);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + 0.25);
    const s = noiseSource(false), f = ctx.createBiquadFilter(), g2 = ctx.createGain();
    f.type = 'lowpass'; f.frequency.value = 900; env(g2, t, 0.003, 0.3, 0.08);
    s.connect(f); f.connect(g2); g2.connect(master); s.start(t, Math.random(), 0.15);
  },

  // Вой волка
  howl() {
    if (!ctx) return;
    const t = ctx.currentTime, o = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter();
    o.type = 'sawtooth';
    o.frequency.setValueAtTime(260, t);
    o.frequency.linearRampToValueAtTime(520, t + 0.7);
    o.frequency.linearRampToValueAtTime(400, t + 1.6);
    o.frequency.linearRampToValueAtTime(280, t + 2.3);
    f.type = 'lowpass'; f.frequency.value = 1100;
    const lfo = ctx.createOscillator(), lg = ctx.createGain();
    lfo.frequency.value = 6; lg.gain.value = 9; lfo.connect(lg); lg.connect(o.frequency);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.18, t + 0.4);
    g.gain.setValueAtTime(0.18, t + 1.6);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 2.4);
    o.connect(f); f.connect(g); g.connect(master);
    o.start(t); lfo.start(t); o.stop(t + 2.5); lfo.stop(t + 2.5);
  },

  // Монета / получение награды
  coin() {
    if (!ctx) return;
    const t = ctx.currentTime;
    [988, 1319].forEach((fr, i) => {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = 'square'; o.frequency.value = fr;
      env(g, t + i * 0.08, 0.005, 0.12, 0.18);
      o.connect(g); g.connect(master); o.start(t + i * 0.08); o.stop(t + i * 0.08 + 0.25);
    });
  },

  // Короткий звук интерфейса
  ui() {
    if (!ctx) return;
    const t = ctx.currentTime, o = ctx.createOscillator(), g = ctx.createGain();
    o.type = 'sine'; o.frequency.value = 660;
    env(g, t, 0.005, 0.15, 0.08);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + 0.15);
  },

  // Громкость ветра, воды у озера (0..1) и дождя (0..1)
  setWind(v) { if (windGain) windGain.gain.setTargetAtTime(0.03 + v * 0.08, ctx.currentTime, 0.5); },
  setWater(v) { if (waterGain) waterGain.gain.setTargetAtTime(v * 0.16, ctx.currentTime, 0.3); },
  setRain(v) { if (rainGain) rainGain.gain.setTargetAtTime(v * 0.07, ctx.currentTime, 0.6); }
};
