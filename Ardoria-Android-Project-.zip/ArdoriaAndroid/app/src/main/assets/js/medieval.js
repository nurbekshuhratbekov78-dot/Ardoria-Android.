// Дополнение: дома с интерьером, конюшня, верховая езда и арена.
import * as THREE from 'three';
import { G } from './game.js';

const mat = (c, roughness=0.9) => new THREE.MeshStandardMaterial({color:c, roughness});
function block(scene, w,h,d, color, x,y,z, parent=scene) {
  const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat(color));
  m.position.set(x,y,z); m.castShadow=true; m.receiveShadow=true; parent.add(m); return m;
}
function label(text) { return text; }
export function initMedieval(scene) {
  const P=G.player;
  P.inventory ||= [{name:'Хлеб',count:3,desc:'Восстанавливает 20 здоровья'},{name:'Зелье лечения',count:1,desc:'Восстанавливает 50 здоровья'},{name:'Золотая монета',count:0,desc:'Валюта королевства'}];
  P.horseOwned=true; P.onHorse=false;
  const ui=document.createElement('div');
  ui.id='medievalPanel';
  ui.style.cssText='position:fixed;z-index:30;inset:8% 5%;max-width:620px;margin:auto;background:linear-gradient(145deg,#241b13f5,#100e0cf5);border:2px solid #bd984c;border-radius:16px;padding:20px;color:#f4e6c7;display:none;overflow:auto;font:15px system-ui;box-shadow:0 12px 60px #000';
  document.body.appendChild(ui);
  function open(title,body,buttons=[]) {
    G.flags.uiOpen=true; ui.style.display='block';
    ui.innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center"><h2 style="color:#e8c872;margin:0">${title}</h2><button id="medClose" style="font-size:22px;background:#49351e;color:white;border:1px solid #b9944b;border-radius:8px;padding:4px 12px">✕</button></div><div style="line-height:1.6;margin:16px 0">${body}</div><div style="display:flex;gap:8px;flex-wrap:wrap">${buttons.map((b,i)=>`<button data-act="${i}" style="background:#c49a3c;border:1px solid #f0d58a;border-radius:8px;padding:10px 14px;color:#211707;font-weight:700">${b.label}</button>`).join('')}</div>`;
    ui.querySelector('#medClose').onclick=close;
    ui.querySelectorAll('[data-act]').forEach(el=>el.onclick=()=>buttons[+el.dataset.act].run());
  }
  function close(){ui.style.display='none';G.flags.uiOpen=false;}
  function house(x,z,name) {
    const g=new THREE.Group(); g.position.set(x,0,z); scene.add(g);
    block(scene,8,4.2,7,0x9b7650,0,2.1,0,g);
    const roof= new THREE.Mesh(new THREE.ConeGeometry(6.2,3.2,4),mat(0x59402c)); roof.position.set(0,5.5,0); roof.rotation.y=Math.PI/4; roof.castShadow=true; g.add(roof);
    block(scene,1.4,2.4,.18,0x4a2816,0,1.2,-3.58,g);
    block(scene,.25,2.5,.12,0xc49a3c,.72,1.25,-3.7,g);
    const door={x,z:z-4.1,r:3,label:`Войти в дом: ${name}`,action:()=>enter(name,x,z)};
    G.addInteractable(door);
    return g;
  }
  // Уютные дополнительные дома и отдельная зона интерьеров.
  const homes=[[-66,-12,'Дом лесника'],[-78,12,'Дом мельника'],[66,34,'Дом торговца']];
  homes.forEach(([x,z,n])=>house(x,z,n));
  const interior=new THREE.Group(); interior.position.set(145,0,145); scene.add(interior);
  block(scene,12,.35,12,0x765334,0,0,0,interior);
  block(scene,12,4,.4,0x765334,0,2,-6,interior); block(scene,12,4,.4,0x765334,0,2,6,interior);
  block(scene,.4,4,12,0x765334,-6,2,0,interior); block(scene,.4,4,12,0x765334,6,2,0,interior);
  block(scene,3,.4,1.5,0x4b2d19,-2,.5,-2,interior);
  block(scene,1.2,1.8,1.2,0x80552f,2,.9,2,interior);
  let returnPoint={x:0,z:0};
  function enter(name,x,z) {
    returnPoint={x,z:z+2}; P.pos.set(145,0,149);
    open(name,'Вы внутри дома. Здесь можно отдохнуть и подготовиться к путешествию.',[
      {label:'Отдохнуть (+25 HP)',run:()=>{P.hp=Math.min(P.maxHp,P.hp+25);G.toast('Вы отдохнули');}},
      {label:'Выйти наружу',run:leave}
    ]);
  }
  function leave(){P.pos.set(returnPoint.x,0,returnPoint.z);close();}
  G.addInteractable({x:145,z:151,r:2.5,label:'Выйти из дома',action:leave});
  // Конюшня и конь
  const horse=new THREE.Group(); horse.position.set(48,0,78); scene.add(horse);
  block(scene,1.5,1.4,2.5,0x704329,0,1.3,0,horse);
  block(scene,.7,1.2,.7,0x704329,0,2.1,-1.1,horse);
  block(scene,.8,.35,.6,0x251a14,0,2.65,-1.25,horse);
  for(const x of [-.55,.55]) for(const z of [-.8,.8]) block(scene,.22,1.1,.22,0x38261a,x,.55,z,horse);
  block(scene,.9,.2,1.1,0x9b1e1e,0,2,0,horse);
  G.addInteractable({x:48,z:78,r:4,label:'Оседлать лошадь',action:()=>{
    if(P.onHorse){P.onHorse=false;P.speedMul=1;G.toast('Вы слезли с лошади');}
    else {P.onHorse=true;P.speedMul=1.75;G.toast('Вы оседлали лошадь · скорость увеличена');}
  }});
  G.addUpdater(dt=>{if(P.onHorse){horse.position.x+=(P.pos.x-horse.position.x)*Math.min(1,dt*8);horse.position.z+=(P.pos.z+1.2-horse.position.z)*Math.min(1,dt*8);horse.rotation.y=Math.atan2(P.vel.x,P.vel.z);}});
  // Арена: тренировочный поединок с наградой, без боевого насилия в деталях.
  const ax=82, az=-58;
  const ring=new THREE.Mesh(new THREE.CylinderGeometry(13,13,.35,32),mat(0x8d6b3f));ring.position.set(ax,.18,az);ring.receiveShadow=true;scene.add(ring);
  for(let i=0;i<12;i++){const a=i*Math.PI/6;block(scene,.35,1.5,.35,0x72502d,ax+14*Math.cos(a),.75,az+14*Math.sin(a));}
  G.addInteractable({x:ax,z:az,r:5,label:'Начать тренировочный бой',action:()=>{
    open('Арена Ардории','Тренировочный поединок. За победу выдаётся опыт и 40 монет.',[
      {label:'Вступить в бой',run:()=>{P.xp+=35;P.coins+=40;G.toast('Победа! +35 XP · +40 монет');close();}},
      {label:'Позже',run:close}
    ]);
  }});
  // Доска заданий
  G.addInteractable({x:6,z:-9,r:3,label:'Доска заданий',action:()=>{
    const done=localStorage.getItem('ardoria_quest_home')==='1';
    open('Задания королевства',`<b>Главное поручение: Осмотреть владения</b><br>Посетите конюшню и арену. Награда: 60 монет и 50 опыта.<br>Статус: ${done?'Выполнено':'Ожидает выполнения'}`,[
      {label:done?'Получено':'Завершить поручение',run:()=>{if(!done){localStorage.setItem('ardoria_quest_home','1');P.coins+=60;P.xp+=50;G.toast('Задание выполнено! +60 монет · +50 XP');}close();}}
    ]);
  }});
  // Инвентарь
  function inventory(){
    const rows=P.inventory.map((it,i)=>`<div style="padding:10px;border-bottom:1px solid #765b34"><b>${it.name}</b> × ${it.count}<br><small>${it.desc}</small>${i<2&&it.count?` <button data-item="${i}" style="float:right;background:#c49a3c;border:0;border-radius:6px;padding:5px">Использовать</button>`:''}</div>`).join('');
    open('Инвентарь',rows||'Пусто');
    ui.querySelectorAll('[data-item]').forEach(el=>el.onclick=()=>{const i=+el.dataset.item,it=P.inventory[i];if(!it.count)return;if(i===0)P.hp=Math.min(P.maxHp,P.hp+20);else P.hp=Math.min(P.maxHp,P.hp+50);it.count--;inventory();G.toast('Предмет использован');});
  }
  G.on('ui:inventory',inventory);
  G.on('ui:quests',()=>open('Журнал заданий','<b>Осмотреть владения</b><br>Посетите конюшню и арену. Подойдите к доске объявлений на площади, чтобы получить награду.'));
  G.on('save',()=>{try{localStorage.setItem('ardoria_save',JSON.stringify({hp:P.hp,coins:P.coins,xp:P.xp,level:P.level,inventory:P.inventory}));G.toast('Сохранение создано');}catch(e){}});
  try{const s=JSON.parse(localStorage.getItem('ardoria_save')||'null');if(s){Object.assign(P,{hp:s.hp??P.hp,coins:s.coins??P.coins,xp:s.xp??P.xp,level:s.level??P.level});if(s.inventory)P.inventory=s.inventory;}}catch(e){}
  G.toast('Новые дома, конюшня и арена доступны на карте');
}
