// Общее состояние игры, шина событий и реестр интерактивных объектов.
// Все модули импортируют отсюда объект G.

export const G = {
  scene: null, camera: null, renderer: null,

  // Состояние игрока (позицию создаёт player.js)
  player: {
    hp: 100, maxHp: 100, stamina: 100, maxStamina: 100,
    xp: 0, level: 1, coins: 0,
    baseDamage: 10, damageBonus: 0, armorBonus: 0,
    speedMul: 1, pos: null
  },

  // Время суток: t от 0 до 1 (0 = полночь, 0.5 = полдень). Сутки = 600 секунд.
  time: { t: 0.3, dayLength: 600, sinSun: 1, daylight: 1, night: 0 },

  // Погода
  weather: { type: 'clear', rain: 0, fog: 0 },

  flags: { started: false, paused: false, uiOpen: false, dialog: false, castleOpen: false },
  elapsed: 0,

  _updaters: [], _listeners: {}, interactables: [], nearest: null,

  // Ввод заблокирован (пауза, окно интерфейса, диалог, игра не начата)
  isBlocked() {
    const f = this.flags;
    return f.paused || f.uiOpen || f.dialog || !f.started;
  },

  // Функции, вызываемые каждый кадр: fn(dt)
  addUpdater(fn) { this._updaters.push(fn); },

  on(ev, fn) { (this._listeners[ev] ||= []).push(fn); },
  emit(ev, ...args) {
    const list = this._listeners[ev];
    if (list) for (const f of list.slice()) f(...args);
  },

  // Интерактивный объект: { x, z, r, label (строка или функция), action(), enabled?(), obj? }
  addInteractable(o) { this.interactables.push(o); return o; },
  removeInteractable(o) {
    const i = this.interactables.indexOf(o);
    if (i >= 0) this.interactables.splice(i, 1);
  },

  // XP, нужный для следующего уровня
  xpForLevel(l) { return 80 + l * 40; },

  // Всплывающее сообщение
  toast(text, ms = 2600) {
    const el = document.getElementById('toast');
    if (!el) return;
    const d = document.createElement('div');
    d.className = 'toastItem';
    d.textContent = text;
    el.appendChild(d);
    setTimeout(() => d.remove(), ms);
  }
};
