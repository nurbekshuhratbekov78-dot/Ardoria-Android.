// Мир 400×400: рельеф, дороги, раскраска земли, деревья, трава, коллизии.
// Север = -Z, восток = +X. Центр карты (0,0) — площадь деревни.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { tex, canvasOf } from './textures.js';

export const SIZE = 400, HALF = 200, SEG = 200, CELL = SIZE / SEG;

// Общая планировка: по ней строятся и земля, и здания (village.js, castle.js, nature.js)
export const LAYOUT = {
  village: {
    x: 0, z: 0, r: 48,
    plaza: { x: 0, z: 0, r: 12 },
    board: { x: 6, z: -9 },
    smithy: { x: -28, z: -4, w: 10, d: 8 },
    tavern: { x: 26, z: 6, w: 14, d: 11 },
    stalls: [{ x: -20, z: 13 }, { x: -11, z: 21 }, { x: 11, z: 21 }],
    houses: [[-14, -26], [14, -26], [-38, 18], [-30, 30], [-12, 36], [12, 36], [34, 24], [42, 6], [-44, -6], [38, -8]]
  },
  castle: { x: 0, z: -150, x0: -35, x1: 35, z0: -180, z1: -120, gate: { x: 0, z: -120 } },
  farm: {
    x: 0, z: 125, r: 62,
    fields: [{ x0: -58, z0: 118, x1: -20, z1: 160 }, { x0: 20, z0: 118, x1: 58, z1: 160 }],
    pen: { x: -38, z: 92, w: 24, d: 20 },
    mill: { x: 40, z: 92 },
    house: { x: 0, z: 128 }
  },
  forest: { x0: -195, x1: -55, z0: -80, z1: 150 },
  witch: { x: -135, z: 45, r: 14 },
  mine: { x: -148, z: -118, r: 30 },
  lake: { x: 125, z: -105, r: 38, level: -0.9 }
};

// ---------- Утилиты ----------
export function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
function hash2(ix, iz) {
  let h = Math.imul(ix, 374761393) ^ Math.imul(iz, 668265263);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}
function vnoise(x, z) {
  const xi = Math.floor(x), zi = Math.floor(z), xf = x - xi, zf = z - zi;
  const u = xf * xf * (3 - 2 * xf), v = zf * zf * (3 - 2 * zf);
  const a = hash2(xi, zi), b = hash2(xi + 1, zi), c = hash2(xi, zi + 1), d = hash2(xi + 1, zi + 1);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
const fbm = (x, z) => vnoise(x, z) * 0.55 + vnoise(x * 2.1, z * 2.1) * 0.3 + vnoise(x * 4.3, z * 4.3) * 0.15;

// ---------- Дороги ----------
function catmull(pts, per = 10) {
  const out = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
    for (let k = 0; k < per; k++) {
      const t = k / per, t2 = t * t, t3 = t2 * t;
      out.push([0, 1].map(a => 0.5 * ((2 * p1[a]) + (-p0[a] + p2[a]) * t +
        (2 * p0[a] - 5 * p1[a] + 4 * p2[a] - p3[a]) * t2 + (-p0[a] + 3 * p1[a] - 3 * p2[a] + p3[a]) * t3)));
    }
  }
  out.push(pts[pts.length - 1]);
  return out;
}

const TYPES = ['brick', 'stone', 'dirt'];
export const ROADS = [];
const SEGS = []; // [ax, az, bx, bz, полуширина, тип]
function addRoad(type, w, pts, smoothIt) {
  const dense = smoothIt ? catmull(pts, 10) : pts;
  ROADS.push({ type, w, pts: dense });
  const ti = TYPES.indexOf(type);
  for (let i = 0; i < dense.length - 1; i++) {
    SEGS.push([dense[i][0], dense[i][1], dense[i + 1][0], dense[i + 1][1], w / 2, ti]);
  }
}
// Кирпичная дорога замок → деревня
addRoad('brick', 5.5, [[0, -118], [3, -95], [-3, -65], [2, -40], [0, -14]], true);
// Грунтовая тропа деревня → ферма
addRoad('dirt', 4, [[0, 14], [3, 40], [-3, 70], [2, 100], [0, 118]], true);
// Каменная тропа к шахте
addRoad('stone', 3.6, [[-14, -10], [-40, -34], [-72, -62], [-108, -92], [-132, -108]], true);
// Тропа в тёмный лес к хижине ведьмы
addRoad('dirt', 3, [[-14, 4], [-55, 9], [-95, 28], [-125, 42]], true);
// Тропа к озеру
addRoad('dirt', 3.2, [[14, -8], [48, -38], [82, -80], [96, -98]], true);
// Дорожки внутри деревни
[
  [[0, 0], [-28, -4]], [[0, 0], [26, 6]],
  [[0, 0], [-20, 13]], [[0, 0], [-11, 21]], [[0, 0], [11, 21]],
  [[0, 0], [-14, -26]], [[0, 0], [14, -26]], [[0, 0], [-38, 18]], [[0, 0], [-30, 30]],
  [[0, 0], [-12, 36]], [[0, 0], [12, 36]], [[0, 0], [34, 24]],
  [[12, -4], [38, -8]], [[38, -8], [42, 6]], [[-8, -8], [-30, -11], [-44, -6]]
].forEach(p => addRoad('dirt', 2.4, p, false));

let _rd = 1e9, _rt = -1;
// Ближайшая дорога: _rd — расстояние до кромки (<0 — на дороге), _rt — тип
function nearestRoad(x, z) {
  let best = 1e9, bt = -1;
  for (let i = 0; i < SEGS.length; i++) {
    const s = SEGS[i], dx = s[2] - s[0], dz = s[3] - s[1], l2 = dx * dx + dz * dz;
    let t = l2 > 0 ? ((x - s[0]) * dx + (z - s[1]) * dz) / l2 : 0;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    const ex = s[0] + dx * t - x, ez = s[1] + dz * t - z;
    const d = Math.sqrt(ex * ex + ez * ez) - s[4];
    if (d < best) { best = d; bt = s[5]; }
  }
  _rd = best; _rt = bt;
}

// ---------- Рельеф ----------
const FLAT = [
  { x: 0, z: 0, ri: 50, ro: 72 },
  { x: 0, z: -150, ri: 55, ro: 80 },
  { x: 0, z: 125, ri: 60, ro: 85 },
  { x: -135, z: 45, ri: 14, ro: 28 },
  { x: -148, z: -118, ri: 30, ro: 48 }
];
function heightRaw(x, z) {
  let h = (fbm(x * 0.016 + 7.3, z * 0.016 + 3.1) - 0.5) * 16;
  const e = Math.max(Math.abs(x), Math.abs(z));
  h += smooth(158, 196, e) * (9 + fbm(x * 0.05, z * 0.05) * 10); // горы по краю карты
  for (const f of FLAT) {
    const w = 1 - smooth(f.ri, f.ro, Math.hypot(x - f.x, z - f.z));
    h = h * (1 - w);
  }
  nearestRoad(x, z);
  if (_rd < 12) h *= 1 - 0.8 * (1 - smooth(2, 12, _rd)); // дороги — более ровные
  const L = LAYOUT.lake, dl = Math.hypot(x - L.x, z - L.z);
  if (dl < L.r + 18) {
    const bowl = dl < L.r ? -3.4 * (1 - (dl / L.r) ** 2) : 0;
    const b = 1 - smooth(L.r, L.r + 18, dl);
    h = h * (1 - b) + bowl * b;
  }
  return h;
}

let HM = null;
function buildHeightmap() {
  HM = new Float32Array((SEG + 1) * (SEG + 1));
  for (let iz = 0; iz <= SEG; iz++)
    for (let ix = 0; ix <= SEG; ix++) HM[iz * (SEG + 1) + ix] = heightRaw(-HALF + ix * CELL, -HALF + iz * CELL);
}

function groundHeight(x, z) {
  const gx = (x + HALF) / CELL, gz = (z + HALF) / CELL;
  const ix = clamp(Math.floor(gx), 0, SEG - 1), iz = clamp(Math.floor(gz), 0, SEG - 1);
  const fx = clamp(gx - ix, 0, 1), fz = clamp(gz - iz, 0, 1);
  const i = iz * (SEG + 1) + ix;
  return (HM[i] * (1 - fx) + HM[i + 1] * fx) * (1 - fz) + (HM[i + SEG + 1] * (1 - fx) + HM[i + SEG + 2] * fx) * fz;
}

// ---------- Поверхности, коллизии ----------
const surfaces = [];
function addSurface(fn) { surfaces.push(fn); }
// Высота пола в точке с учётом поверхностей (этажи, ступени); y — высота ног
function heightAt(x, z, y) {
  let h = groundHeight(x, z);
  for (const s of surfaces) {
    const v = s(x, z, y);
    if (v != null && v > h && v <= y + 0.7) h = v;
  }
  return h;
}

const circleGrid = new Map(), boxes = [];
function addCircle(x, z, r) {
  const k = Math.floor(x / 10) + ',' + Math.floor(z / 10);
  let a = circleGrid.get(k);
  if (!a) { a = []; circleGrid.set(k, a); }
  a.push({ x, z, r });
}
// Прямоугольный коллайдер; y0/y1 — необязательный диапазон высот (стены, но не крыши над головой)
function addBox(x0, z0, x1, z1, y0 = -Infinity, y1 = Infinity) {
  boxes.push({ x0: Math.min(x0, x1), z0: Math.min(z0, z1), x1: Math.max(x0, x1), z1: Math.max(z0, z1), y0, y1 });
}
function resolve(pos, r) {
  const cx = Math.floor(pos.x / 10), cz = Math.floor(pos.z / 10);
  for (let ix = cx - 1; ix <= cx + 1; ix++)
    for (let iz = cz - 1; iz <= cz + 1; iz++) {
      const arr = circleGrid.get(ix + ',' + iz);
      if (!arr) continue;
      for (const c of arr) {
        const dx = pos.x - c.x, dz = pos.z - c.z, rr = r + c.r, d2 = dx * dx + dz * dz;
        if (d2 < rr * rr) {
          const d = Math.sqrt(d2) || 0.0001;
          pos.x = c.x + dx / d * rr; pos.z = c.z + dz / d * rr;
        }
      }
    }
  const y = pos.y;
  for (const b of boxes) {
    if (y >= b.y1 - 0.3 || y + 1.8 <= b.y0) continue;
    if (pos.x < b.x0 - r || pos.x > b.x1 + r || pos.z < b.z0 - r || pos.z > b.z1 + r) continue;
    const nx = clamp(pos.x, b.x0, b.x1), nz = clamp(pos.z, b.z0, b.z1);
    const dx = pos.x - nx, dz = pos.z - nz, d2 = dx * dx + dz * dz;
    if (d2 >= r * r && d2 > 0) continue;
    if (d2 > 0) {
      const d = Math.sqrt(d2);
      pos.x = nx + dx / d * r; pos.z = nz + dz / d * r;
    } else {
      const l = pos.x - b.x0, rt = b.x1 - pos.x, u = pos.z - b.z0, dn = b.z1 - pos.z;
      const m = Math.min(l, rt, u, dn);
      if (m === l) pos.x = b.x0 - r; else if (m === rt) pos.x = b.x1 + r;
      else if (m === u) pos.z = b.z0 - r; else pos.z = b.z1 + r;
    }
  }
}

const noGrass = [];
function addNoGrass(x0, z0, x1, z1) { noGrass.push([Math.min(x0, x1), Math.min(z0, z1), Math.max(x0, x1), Math.max(z0, z1)]); }

// ---------- Типы местности ----------
function forestFactor(x, z) {
  const F = LAYOUT.forest;
  const d = Math.hypot(Math.max(F.x0 - x, 0, x - F.x1), Math.max(F.z0 - z, 0, z - F.z1));
  return 1 - smooth(0, 25, d);
}
function roadType(x, z) {
  const V = LAYOUT.village;
  if (Math.hypot(x - V.plaza.x, z - V.plaza.z) < V.plaza.r) return 'plaza';
  const C = LAYOUT.castle;
  if (x > C.x0 && x < C.x1 && z > C.z0 && z < C.z1) return 'courtyard';
  nearestRoad(x, z);
  if (_rd < 0.3 && _rt >= 0) return TYPES[_rt];
  return 'grass';
}
function roadDist(x, z) { nearestRoad(x, z); return _rd; }
function inLake(x, z) {
  const L = LAYOUT.lake;
  return Math.hypot(x - L.x, z - L.z) < L.r && groundHeight(x, z) < L.level;
}

// ---------- Раскраска земли (canvas 2048×2048 на всю карту) ----------
function tile(name, size) {
  const t = document.createElement('canvas');
  t.width = t.height = size;
  t.getContext('2d').drawImage(canvasOf(name), 0, 0, size, size);
  return t;
}

function paintGround() {
  const W = 2048, S = W / SIZE;
  const c = document.createElement('canvas'); c.width = c.height = W;
  const g = c.getContext('2d'), rnd = mulberry32(77);
  const px = x => (x + HALF) * S, pz = z => (z + HALF) * S;
  const blob = (x, y, r, col) => {
    const gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, col); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
  };
  // Трава с пятнами разных оттенков
  g.fillStyle = '#4e8b39'; g.fillRect(0, 0, W, W);
  for (let i = 0; i < 700; i++)
    blob(rnd() * W, rnd() * W, 30 + rnd() * 90, rnd() < 0.5 ? 'rgba(120,170,70,0.28)' : 'rgba(30,80,40,0.28)');

  // Лесная подстилка
  const F = LAYOUT.forest;
  for (let i = 0; i < 1100; i++) {
    const x = F.x0 - 10 + rnd() * (F.x1 - F.x0 + 20), z = F.z0 - 10 + rnd() * (F.z1 - F.z0 + 20);
    blob(px(x), pz(z), (6 + rnd() * 10) * S, rnd() < 0.7 ? 'rgba(18,45,24,0.5)' : 'rgba(70,52,28,0.35)');
  }

  // Песок у озера
  const L = LAYOUT.lake;
  const sg = g.createRadialGradient(px(L.x), pz(L.z), 0, px(L.x), pz(L.z), (L.r + 14) * S);
  sg.addColorStop(0, '#cdb982'); sg.addColorStop(0.82, '#d9c58d');
  sg.addColorStop(0.93, 'rgba(217,197,141,0.9)'); sg.addColorStop(1, 'rgba(217,197,141,0)');
  g.fillStyle = sg; g.fillRect(px(L.x - L.r - 16), pz(L.z - L.r - 16), (L.r + 16) * 2 * S, (L.r + 16) * 2 * S);

  // Вспаханные поля
  const furrow = document.createElement('canvas'); furrow.width = furrow.height = 16;
  const fg = furrow.getContext('2d');
  fg.fillStyle = '#6b4a2b'; fg.fillRect(0, 0, 16, 16); fg.fillStyle = '#4d341d'; fg.fillRect(0, 8, 16, 8);
  g.fillStyle = g.createPattern(furrow, 'repeat');
  for (const f of LAYOUT.farm.fields) g.fillRect(px(f.x0), pz(f.z0), (f.x1 - f.x0) * S, (f.z1 - f.z0) * S);

  // Дворы кузни и таверны
  const dirtP = g.createPattern(tile('dirt', 64), 'repeat');
  g.fillStyle = dirtP;
  const V = LAYOUT.village;
  for (const [x, z, r] of [[V.smithy.x, V.smithy.z + 2, 9], [V.tavern.x, V.tavern.z + 2, 11]]) {
    g.beginPath(); g.arc(px(x), pz(z), r * S, 0, 6.283); g.fill();
  }

  // Дороги
  const pats = { brick: g.createPattern(tile('brick', 40), 'repeat'), stone: g.createPattern(tile('stone', 36), 'repeat'), dirt: dirtP };
  g.lineCap = 'round'; g.lineJoin = 'round';
  for (const r of ROADS) {
    const path = () => {
      g.beginPath();
      r.pts.forEach((p, i) => { if (i === 0) g.moveTo(px(p[0]), pz(p[1])); else g.lineTo(px(p[0]), pz(p[1])); });
      g.stroke();
    };
    if (r.type === 'dirt') {
      g.strokeStyle = 'rgba(90,70,45,0.25)'; g.lineWidth = (r.w + 2.6) * S; path();
      g.strokeStyle = 'rgba(90,70,45,0.45)'; g.lineWidth = (r.w + 1.4) * S; path();
    } else {
      g.strokeStyle = 'rgba(40,35,30,0.6)'; g.lineWidth = (r.w + 0.9) * S; path();
    }
    g.strokeStyle = pats[r.type]; g.lineWidth = r.w * S; path();
  }

  // Каменная площадь деревни
  g.fillStyle = 'rgba(40,35,30,0.7)';
  g.beginPath(); g.arc(px(V.plaza.x), pz(V.plaza.z), (V.plaza.r + 0.6) * S, 0, 6.283); g.fill();
  g.fillStyle = pats.stone;
  g.beginPath(); g.arc(px(V.plaza.x), pz(V.plaza.z), V.plaza.r * S, 0, 6.283); g.fill();

  // Каменный двор замка
  const C = LAYOUT.castle;
  g.fillStyle = pats.stone;
  g.fillRect(px(C.x0 + 1), pz(C.z0 + 1), (C.x1 - C.x0 - 2) * S, (C.z1 - C.z0 - 2) * S);

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  return t;
}

// ---------- Деревья ----------
function buildTerrain(scene) {
  const groundTex = paintGround();
  const geo = new THREE.PlaneGeometry(SIZE, SIZE, SEG, SEG);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const ix = Math.round((pos.getX(i) + HALF) / CELL), iz = Math.round((pos.getZ(i) + HALF) / CELL);
    pos.setY(i, HM[iz * (SEG + 1) + ix]);
  }
  geo.computeVertexNormals();
  const mat = new THREE.MeshLambertMaterial({ map: groundTex });
  const detail = tex('detail');
  // Мелкая текстура-детализация поверх общей карты земли
  mat.onBeforeCompile = (sh) => {
    sh.uniforms.detailMap = { value: detail };
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <map_pars_fragment>', '#include <map_pars_fragment>\nuniform sampler2D detailMap;')
      .replace('#include <map_fragment>', '#include <map_fragment>\n diffuseColor.rgb *= texture2D(detailMap, vMapUv * 90.0).rgb * 1.5;');
  };
  const mesh = new THREE.Mesh(geo, mat);
  mesh.receiveShadow = true;
  scene.add(mesh);
}

const occ = new Map();
function occupy(x, z, minD) {
  const cx = Math.floor(x / 5), cz = Math.floor(z / 5), n = Math.ceil(minD / 5);
  for (let i = cx - n; i <= cx + n; i++)
    for (let j = cz - n; j <= cz + n; j++) {
      const a = occ.get(i + ',' + j);
      if (a) for (const p of a) if (Math.hypot(p[0] - x, p[1] - z) < minD) return false;
    }
  const k = cx + ',' + cz;
  if (!occ.has(k)) occ.set(k, []);
  occ.get(k).push([x, z]);
  return true;
}

function treeBlocked(x, z) {
  if (roadDist(x, z) < 3.5) return true;
  const V = LAYOUT.village, C = LAYOUT.castle, W = LAYOUT.witch, M = LAYOUT.mine, L = LAYOUT.lake, Fm = LAYOUT.farm;
  if (Math.hypot(x - V.x, z - V.z) < 52) return true;
  if (x > C.x0 - 14 && x < C.x1 + 14 && z > C.z0 - 20 && z < C.z1 + 14) return true;
  if (Math.hypot(x - Fm.x, z - Fm.z) < 64) return true;
  if (Math.hypot(x - W.x, z - W.z) < W.r + 5) return true;
  if (Math.hypot(x - M.x, z - M.z) < M.r + 6) return true;
  if (Math.hypot(x - L.x, z - L.z) < L.r + 8) return true;
  return false;
}

function placeTrees(list, count, region, minD, rnd, accept, sMin, sMax) {
  let tries = 0;
  while (list.length < count && tries < count * 100) {
    tries++;
    const x = region.x0 + rnd() * (region.x1 - region.x0), z = region.z0 + rnd() * (region.z1 - region.z0);
    if (treeBlocked(x, z) || !accept(x, z)) continue;
    if (!occupy(x, z, minD)) continue;
    list.push({ x, z, s: sMin + rnd() * (sMax - sMin), r: rnd() });
  }
}

const _d = new THREE.Object3D();
function fillInstances(mesh, list, tint) {
  list.forEach((t, i) => {
    _d.position.set(t.x, groundHeight(t.x, t.z) - 0.15, t.z);
    _d.rotation.set((t.r - 0.5) * 0.08, t.r * 6.283, (t.r - 0.5) * 0.08);
    _d.scale.set(t.s, t.s * (0.9 + t.r * 0.3), t.s);
    _d.updateMatrix();
    mesh.setMatrixAt(i, _d.matrix);
    if (tint) { const v = 0.55 + t.r * 0.4; mesh.setColorAt(i, new THREE.Color(v * 0.92, v, v * 0.92)); }
  });
  mesh.instanceMatrix.needsUpdate = true;
  if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
}

function buildTrees(scene) {
  const rnd = mulberry32(1234), F = LAYOUT.forest;
  const spruces = [], oaks = [];
  // Густой лес на западе (~210 елей): плотность задаёт шум, получаются заросли и поляны
  placeTrees(spruces, 210, F, 3.4, rnd, (x, z) => rnd() < 0.2 + 0.95 * smooth(0.33, 0.62, vnoise(x * 0.05 + 3, z * 0.05 + 9)), 1.1, 2.0);
  // Одиночные ели и дубы по остальной карте
  const all = { x0: -188, x1: 188, z0: -188, z1: 188 };
  const outside = (x, z) => !(x > F.x0 - 5 && x < F.x1 + 5 && z > F.z0 - 5 && z < F.z1 + 5);
  const nSpruce = spruces.length;
  placeTrees(spruces, nSpruce + 55, all, 5, rnd, outside, 0.8, 1.3);
  placeTrees(oaks, 45, all, 6, rnd, outside, 0.9, 1.4);

  for (const t of spruces) addCircle(t.x, t.z, 0.55 * t.s);
  for (const t of oaks) addCircle(t.x, t.z, 0.5 * t.s);

  // Ель: ствол + три яруса конусов, один InstancedMesh на всё
  const trunkGeo = new THREE.CylinderGeometry(0.22, 0.34, 2.4, 6); trunkGeo.translate(0, 1.2, 0);
  const cones = [[2.3, 2.8, 1.9], [1.85, 2.6, 3.5], [1.35, 2.4, 5.0]].map(([r, h, y]) => {
    const g = new THREE.ConeGeometry(r, h, 7, 1); g.translate(0, y + h / 2, 0); return g;
  });
  const foliageGeo = mergeGeometries(cones);
  const trunkMat = new THREE.MeshLambertMaterial({ map: tex('wood', 1, 2) });
  const sTrunk = new THREE.InstancedMesh(trunkGeo, trunkMat, spruces.length);
  const sFol = new THREE.InstancedMesh(foliageGeo, new THREE.MeshLambertMaterial({ map: tex('foliage', 2, 2) }), spruces.length);
  fillInstances(sTrunk, spruces, false); fillInstances(sFol, spruces, true);
  sTrunk.castShadow = sFol.castShadow = true;
  scene.add(sTrunk, sFol);

  // Дуб: ствол + две сферы листвы
  const oTrunkGeo = new THREE.CylinderGeometry(0.28, 0.4, 2.4, 6); oTrunkGeo.translate(0, 1.2, 0);
  const c1 = new THREE.SphereGeometry(2.1, 8, 6); c1.scale(1, 0.85, 1); c1.translate(0, 3.6, 0);
  const c2 = new THREE.SphereGeometry(1.4, 7, 5); c2.translate(1.0, 3.0, 0.6);
  const crownGeo = mergeGeometries([c1, c2]);
  const oTrunk = new THREE.InstancedMesh(oTrunkGeo, trunkMat, oaks.length);
  const oCrown = new THREE.InstancedMesh(crownGeo, new THREE.MeshLambertMaterial({ map: tex('leaf', 2, 2) }), oaks.length);
  fillInstances(oTrunk, oaks, false); fillInstances(oCrown, oaks, true);
  oTrunk.castShadow = oCrown.castShadow = true;
  scene.add(oTrunk, oCrown);
  world.treeCount = spruces.length + oaks.length;
}

// ---------- Трава: пучки вокруг игрока (по сетке, без «мерцания») ----------
const GR_HALF = 44, GR_CELL = 1.6, GR_N = Math.floor(GR_HALF * 2 / GR_CELL) + 1;
let grassMesh = null, grassCX = 1e9, grassCZ = 1e9;

function buildGrass(scene) {
  const g1 = new THREE.PlaneGeometry(1.1, 0.9); g1.translate(0, 0.45, 0);
  const g2 = g1.clone(); g2.rotateY(Math.PI / 2);
  const mat = new THREE.MeshLambertMaterial({ map: tex('tuft'), alphaTest: 0.45, side: THREE.DoubleSide });
  grassMesh = new THREE.InstancedMesh(mergeGeometries([g1, g2]), mat, GR_N * GR_N);
  grassMesh.frustumCulled = false; grassMesh.count = 0;
  scene.add(grassMesh);
}

function grassOK(x, z, r) {
  const L = LAYOUT.lake, V = LAYOUT.village, C = LAYOUT.castle;
  if (Math.hypot(x - V.plaza.x, z - V.plaza.z) < V.plaza.r + 0.6) return false;
  if (x > C.x0 - 1 && x < C.x1 + 1 && z > C.z0 - 1 && z < C.z1 + 1) return false;
  for (const f of LAYOUT.farm.fields) if (x > f.x0 - 1 && x < f.x1 + 1 && z > f.z0 - 1 && z < f.z1 + 1) return false;
  for (const b of noGrass) if (x > b[0] && x < b[2] && z > b[1] && z < b[3]) return false;
  nearestRoad(x, z);
  if (_rd < 0.9) return false;
  if (Math.hypot(x - L.x, z - L.z) < L.r + 4 && groundHeight(x, z) < -0.2) return false;
  if (forestFactor(x, z) > 0.99) return r < 0.4;
  return true;
}

function refreshGrass(px, pz) {
  let n = 0;
  const cx = Math.floor(px / GR_CELL), cz = Math.floor(pz / GR_CELL), half = Math.floor(GR_N / 2);
  for (let ix = cx - half; ix <= cx + half; ix++)
    for (let iz = cz - half; iz <= cz + half; iz++) {
      const h1 = hash2(ix, iz), h2 = hash2(ix + 911, iz - 377), h3 = hash2(ix - 53, iz + 719);
      const x = (ix + h1) * GR_CELL, z = (iz + h2) * GR_CELL;
      if (Math.abs(x) > HALF - 4 || Math.abs(z) > HALF - 4) continue;
      const dist = Math.hypot(x - px, z - pz);
      if (dist > GR_HALF) continue;
      const s = (0.7 + h3 * 0.7) * (1 - smooth(GR_HALF - 12, GR_HALF, dist));
      if (s < 0.08 || !grassOK(x, z, h3)) continue;
      _d.position.set(x, groundHeight(x, z) - 0.02, z);
      _d.rotation.set(0, h1 * 6.283, 0);
      _d.scale.set(s, s * (0.8 + h2 * 0.5), s);
      _d.updateMatrix();
      grassMesh.setMatrixAt(n++, _d.matrix);
    }
  grassMesh.count = n;
  grassMesh.instanceMatrix.needsUpdate = true;
}

// ---------- Публичный API ----------
export const world = {
  groundHeight, heightAt, resolve,
  addCircle, addBox, addSurface, addNoGrass,
  roadType, roadDist, forestFactor, inLake,
  treeCount: 0,

  // Строит мир асинхронно, сообщая о ходе загрузки
  async build(scene, progress = async () => {}) {
    await progress('Поднимаем рельеф…');
    buildHeightmap();
    await progress('Рисуем дороги и поля…');
    buildTerrain(scene);
    await progress('Сажаем лес…');
    buildTrees(scene);
    await progress('Растим траву…');
    buildGrass(scene);
  },

  update(dt, px, pz) {
    if (Math.abs(px - grassCX) > 6 || Math.abs(pz - grassCZ) > 6) {
      refreshGrass(px, pz); grassCX = px; grassCZ = pz;
    }
  }
};
