// Игрок: модель-гуманоид, движение, прыжок, бег, камера от третьего лица,
// ввод (клавиатура + мышь с PointerLock, а также сенсорное управление для планшета).
import * as THREE from 'three';
import { G } from './game.js';
import { world, HALF } from './world.js';
import { audio } from './audio.js';
import { tex } from './textures.js';

export const isTouch = (window.matchMedia && matchMedia('(pointer: coarse)').matches) || 'ontouchstart' in window;
const $ = id => document.getElementById(id);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

const keys = {};
const input = { joyX: 0, joyY: 0, runToggle: false, block: false, jump: false };
export const cam = { yaw: 0, pitch: 0.42, dist: 7.5, cur: 7.5 };

// ---------- Модель из боксов (используется и игроком, и NPC) ----------
export function createHumanoid(o = {}) {
  const mat = c => new THREE.MeshLambertMaterial({ color: c });
  const skin = mat(o.skin ?? 0xe0b48a), shirt = mat(o.shirt ?? 0x3a5ea8), pants = mat(o.pants ?? 0x4a3a2a);
  const hair = mat(o.hair ?? 0x3b2a1a), boot = mat(0x2a2018), dark = mat(0x111111);
  const g = new THREE.Group();
  const box = (w, h, d, m, x, y, z) => {
    const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
    b.position.set(x, y, z); b.castShadow = true; return b;
  };
  g.add(box(0.7, 0.8, 0.36, shirt, 0, 1.2, 0));
  const head = new THREE.Group(); head.position.set(0, 1.62, 0);
  head.add(box(0.42, 0.42, 0.42, skin, 0, 0.22, 0));
  head.add(box(0.46, 0.14, 0.46, hair, 0, 0.45, -0.02));
  head.add(box(0.46, 0.32, 0.1, hair, 0, 0.3, -0.19));
  head.add(box(0.07, 0.07, 0.03, dark, -0.1, 0.25, 0.215));
  head.add(box(0.07, 0.07, 0.03, dark, 0.1, 0.25, 0.215));
  g.add(head);
  const limb = (w, h, d, m, x, y, tipMat, tipH) => {
    const p = new THREE.Group(); p.position.set(x, y, 0);
    p.add(box(w, h, d, m, 0, -h / 2, 0));
    if (tipMat) p.add(box(w, tipH, d, tipMat, 0, -h + tipH / 2, 0));
    return p;
  };
  const armL = limb(0.2, 0.72, 0.22, shirt, -0.46, 1.55, skin, 0.16);
  const armR = limb(0.2, 0.72, 0.22, shirt, 0.46, 1.55, skin, 0.16);
  const legL = limb(0.3, 0.8, 0.32, pants, -0.17, 0.8, boot, 0.16);
  const legR = limb(0.3, 0.8, 0.32, pants, 0.17, 0.8, boot, 0.16);
  g.add(armL, armR, legL, legR);
  g.scale.setScalar(o.scale ?? 1);
  return { group: g, head, armL, armR, legL, legR };
}

// Покачивание конечностей при ходьбе
export function animateHumanoid(h, phase, amt) {
  h.legL.rotation.x = Math.sin(phase) * 0.8 * amt;
  h.legR.rotation.x = -Math.sin(phase) * 0.8 * amt;
  h.armL.rotation.x = -Math.sin(phase) * 0.7 * amt;
  h.armR.rotation.x = Math.sin(phase) * 0.7 * amt;
}

// ---------- Состояние игрока ----------
let H = null, sword = null, shield = null;
let attackT = -1, swingSent = false, walkPhase = 0, walkAmt = 0, stepAcc = 0, staminaDelay = 0;
const ATTACK_DUR = 0.38;

export function tryAttack() {
  const P = G.player;
  if (G.isBlocked() || attackT >= 0 || P.blocking || P.stamina < 10) return false;
  P.stamina -= 10; staminaDelay = 0.8;
  attackT = 0; swingSent = false;
  audio.sword();
  return true;
}

export function initPlayer(scene, camera) {
  const P = G.player;
  P.pos = new THREE.Vector3(0, 0, 14);
  P.pos.y = world.groundHeight(0, 14);
  P.vel = new THREE.Vector3(); P.vy = 0; P.onGround = true;
  P.heading = Math.PI; P.blocking = false; P.attacking = false; P.exhausted = false; P.running = false;
  G.camera = camera;

  H = createHumanoid({});
  // Меч в правой руке
  sword = new THREE.Group(); sword.position.set(0, -0.72, 0.05); sword.rotation.x = 2.2;
  const metal = new THREE.MeshLambertMaterial({ color: 0xcfd6dd }), leather = new THREE.MeshLambertMaterial({ color: 0x4a2f18 });
  const blade = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.95, 0.02), metal); blade.position.y = 0.62;
  const guard = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.06, 0.07), new THREE.MeshLambertMaterial({ color: 0xb08a2e })); guard.position.y = 0.12;
  const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.2, 6), leather);
  const pommel = new THREE.Mesh(new THREE.SphereGeometry(0.05, 6, 5), guard.material); pommel.position.y = -0.12;
  blade.castShadow = true;
  sword.add(blade, guard, grip, pommel);
  H.armR.add(sword);
  // Щит на левой руке (виден только при блоке)
  shield = new THREE.Group(); shield.position.set(0, -0.4, 0.2); shield.visible = false;
  const sb = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.72, 0.06), new THREE.MeshLambertMaterial({ map: tex('wood') }));
  const rim = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.76, 0.03), metal); rim.position.z = -0.03;
  shield.add(rim, sb); H.armL.add(shield);

  scene.add(H.group);
  H.group.position.copy(P.pos);
  setupInput();
}

// ---------- Ввод ----------
function locked() { return document.pointerLockElement === $('game'); }
export function lockPointer() { if (!isTouch && !locked()) $('game').requestPointerLock?.(); }
export function unlockPointer() { if (locked()) document.exitPointerLock(); }

function setupInput() {
  window.addEventListener('keydown', e => {
    if (e.repeat) return;
    keys[e.code] = true;
    if (!G.flags.started) return;
    switch (e.code) {
      case 'Space': e.preventDefault(); input.jump = true; break;
      case 'KeyE': G.emit('interact'); break;
      case 'KeyI': G.emit('ui:inventory'); break;
      case 'KeyM': G.emit('ui:map'); break;
      case 'Tab': e.preventDefault(); G.emit('ui:quests'); break;
      case 'Escape': G.emit('ui:escape'); break;
    }
  });
  window.addEventListener('keyup', e => { keys[e.code] = false; });
  window.addEventListener('blur', () => { for (const k in keys) keys[k] = false; input.block = false; });

  if (!isTouch) {
    $('game').addEventListener('click', () => {
      if (G.flags.started && !G.isBlocked() && !locked()) lockPointer();
    });
    document.addEventListener('pointerlockchange', () => {
      if (!locked() && G.flags.started && !G.flags.uiOpen && !G.flags.paused) G.emit('ui:escape');
    });
    document.addEventListener('mousemove', e => {
      if (!locked() || G.isBlocked()) return;
      cam.yaw -= e.movementX * 0.0024;
      cam.pitch = clamp(cam.pitch + e.movementY * 0.002, -0.3, 1.3);
    });
    document.addEventListener('mousedown', e => {
      if (!locked() || G.isBlocked()) return;
      if (e.button === 0) tryAttack(); else if (e.button === 2) input.block = true;
    });
    document.addEventListener('mouseup', e => { if (e.button === 2) input.block = false; });
    document.addEventListener('contextmenu', e => e.preventDefault());
    window.addEventListener('wheel', e => { cam.dist = clamp(cam.dist + e.deltaY * 0.008, 2.5, 14); }, { passive: true });
  } else {
    setupTouch();
  }
}

function setupTouch() {
  document.body.classList.add('touch');
  const joyZone = $('joyZone'), base = $('joyBase'), knob = $('joyKnob');
  let joyId = null, ox = 0, oy = 0;
  const R = 60;
  joyZone.addEventListener('pointerdown', e => {
    if (joyId !== null) return;
    joyId = e.pointerId; joyZone.setPointerCapture(e.pointerId);
    ox = e.clientX; oy = e.clientY;
    base.style.left = ox + 'px'; base.style.top = oy + 'px'; base.classList.add('on');
    knob.style.transform = 'translate(-50%, -50%)';
  });
  joyZone.addEventListener('pointermove', e => {
    if (e.pointerId !== joyId) return;
    let dx = e.clientX - ox, dy = e.clientY - oy;
    const l = Math.hypot(dx, dy);
    if (l > R) { dx = dx / l * R; dy = dy / l * R; }
    knob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
    input.joyX = dx / R; input.joyY = -dy / R;
  });
  const endJoy = e => {
    if (e.pointerId !== joyId) return;
    joyId = null; input.joyX = 0; input.joyY = 0; base.classList.remove('on');
  };
  joyZone.addEventListener('pointerup', endJoy);
  joyZone.addEventListener('pointercancel', endJoy);

  // Камера: один палец — поворот, два пальца — зум
  const look = $('lookZone'), ptrs = new Map();
  let pinch = 0;
  const pdist = () => { const v = [...ptrs.values()]; return Math.hypot(v[0].x - v[1].x, v[0].y - v[1].y); };
  look.addEventListener('pointerdown', e => {
    look.setPointerCapture(e.pointerId);
    ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (ptrs.size === 2) pinch = pdist();
  });
  look.addEventListener('pointermove', e => {
    const p = ptrs.get(e.pointerId);
    if (!p) return;
    const dx = e.clientX - p.x, dy = e.clientY - p.y;
    p.x = e.clientX; p.y = e.clientY;
    if (G.isBlocked()) return;
    if (ptrs.size === 1) {
      cam.yaw -= dx * 0.0055;
      cam.pitch = clamp(cam.pitch + dy * 0.0045, -0.3, 1.3);
    } else if (ptrs.size === 2) {
      const d = pdist();
      cam.dist = clamp(cam.dist - (d - pinch) * 0.02, 2.5, 14);
      pinch = d;
    }
  });
  const endLook = e => { ptrs.delete(e.pointerId); };
  look.addEventListener('pointerup', endLook);
  look.addEventListener('pointercancel', endLook);

  // Кнопки
  const press = (id, down, up) => {
    const el = $(id);
    el.addEventListener('pointerdown', e => { e.preventDefault(); el.setPointerCapture(e.pointerId); down(); });
    if (up) {
      el.addEventListener('pointerup', up);
      el.addEventListener('pointercancel', up);
    }
  };
  press('bAtk', () => tryAttack());
  press('bBlock', () => { input.block = true; }, () => { input.block = false; });
  press('bJump', () => { input.jump = true; });
  press('bRun', () => { input.runToggle = !input.runToggle; $('bRun').classList.toggle('on', input.runToggle); });
  press('bUse', () => G.emit('interact'));
  press('bInv', () => G.emit('ui:inventory'));
  press('bMap', () => G.emit('ui:map'));
  press('bQuest', () => G.emit('ui:quests'));
  press('bPause', () => G.emit('ui:escape'));
}

// ---------- Взаимодействие (подсказка «E — …») ----------
function updateInteract() {
  const P = G.player, prompt = $('prompt');
  let best = null, bd = 1e9;
  if (!G.isBlocked()) {
    for (const o of G.interactables) {
      if (o.enabled && !o.enabled()) continue;
      const ox = o.obj ? o.obj.position.x : o.x, oz = o.obj ? o.obj.position.z : o.z;
      const d = Math.hypot(ox - P.pos.x, oz - P.pos.z);
      if (d < (o.r ?? 2.6) && d < bd) { bd = d; best = o; }
    }
  }
  G.nearest = best;
  if (best) {
    const label = typeof best.label === 'function' ? best.label() : best.label;
    prompt.textContent = (isTouch ? '✋ ' : '[E] ') + label;
    prompt.classList.remove('hidden');
  } else {
    prompt.classList.add('hidden');
  }
}
G.on('interact', () => {
  if (G.isBlocked() || !G.nearest) return;
  G.nearest.action();
});

// ---------- Кадр игрока ----------
const _f = new THREE.Vector3();
export function updatePlayer(dt) {
  const P = G.player, blocked = G.isBlocked();

  // Желаемое направление относительно камеры
  let mx = 0, my = 0;
  if (!blocked) {
    mx = (keys.KeyD || keys.ArrowRight ? 1 : 0) - (keys.KeyA || keys.ArrowLeft ? 1 : 0) + input.joyX;
    my = (keys.KeyW || keys.ArrowUp ? 1 : 0) - (keys.KeyS || keys.ArrowDown ? 1 : 0) + input.joyY;
    const l = Math.hypot(mx, my);
    if (l > 1) { mx /= l; my /= l; }
  }
  const sy = Math.sin(cam.yaw), cy = Math.cos(cam.yaw);
  const fx = -sy, fz = -cy, rx = cy, rz = -sy;
  const dx = fx * my + rx * mx, dz = fz * my + rz * mx;
  const moving = Math.hypot(mx, my) > 0.08;

  P.attacking = attackT >= 0;
  P.blocking = !blocked && input.block && !P.attacking;

  // Бег и выносливость
  const wantRun = !blocked && (keys.ShiftLeft || keys.ShiftRight || input.runToggle);
  if (P.exhausted && P.stamina > 20) P.exhausted = false;
  P.running = moving && wantRun && !P.exhausted && P.stamina > 0 && !P.blocking;
  if (P.running) {
    P.stamina -= 16 * dt; staminaDelay = 0.7;
    if (P.stamina <= 0) { P.stamina = 0; P.exhausted = true; }
  } else {
    staminaDelay -= dt;
    if (staminaDelay <= 0) P.stamina = Math.min(P.maxStamina, P.stamina + 14 * dt);
  }

  // Скорость
  let speed = P.running ? 8 : 4.3;
  if (P.blocking) speed *= 0.45;
  if (P.attacking) speed *= 0.6;
  speed *= P.speedMul;
  const k = 1 - Math.exp(-dt * (P.onGround ? 14 : 3));
  P.vel.x += (dx * speed * (moving ? 1 : 0) - P.vel.x) * k;
  P.vel.z += (dz * speed * (moving ? 1 : 0) - P.vel.z) * k;

  // Прыжок
  if (input.jump) {
    if (!blocked && P.onGround && P.stamina >= 8) { P.vy = 7.2; P.onGround = false; P.stamina -= 5; staminaDelay = 0.8; }
    input.jump = false;
  }
  if (!P.onGround) { P.vy -= 22 * dt; P.pos.y += P.vy * dt; }

  // Перемещение + коллизии + границы карты
  P.pos.x += P.vel.x * dt; P.pos.z += P.vel.z * dt;
  world.resolve(P.pos, 0.45);
  P.pos.x = clamp(P.pos.x, -HALF + 8, HALF - 8); P.pos.z = clamp(P.pos.z, -HALF + 8, HALF - 8);

  // Земля под ногами
  const gy = world.heightAt(P.pos.x, P.pos.z, P.pos.y);
  if (P.onGround) {
    if (gy < P.pos.y - 0.45) { P.onGround = false; P.vy = 0; } else P.pos.y = gy;
  }
  if (!P.onGround && P.pos.y <= gy && P.vy <= 0) {
    P.pos.y = gy; P.vy = 0; P.onGround = true;
    audio.step(world.roadType(P.pos.x, P.pos.z));
  }

  // Поворот модели
  const hs = Math.hypot(P.vel.x, P.vel.z);
  let target = P.heading;
  if (P.attacking || P.blocking) target = Math.atan2(fx, fz);
  else if (hs > 0.5) target = Math.atan2(P.vel.x, P.vel.z);
  let da = target - P.heading;
  da = Math.atan2(Math.sin(da), Math.cos(da));
  P.heading += da * Math.min(1, dt * 12);

  // Шаги и анимация
  if (P.onGround && hs > 0.5) {
    walkPhase += dt * hs * 1.9;
    walkAmt = Math.min(1, hs / 5);
    stepAcc += hs * dt;
    if (stepAcc > (P.running ? 3.4 : 2.3)) { stepAcc = 0; audio.step(world.roadType(P.pos.x, P.pos.z)); }
  } else {
    walkAmt *= Math.max(0, 1 - dt * 10);
  }
  animateHumanoid(H, walkPhase, walkAmt);

  // Атака мечом (замах → удар); в середине взмаха сообщаем боевой системе
  if (attackT >= 0) {
    attackT += dt;
    const p = Math.min(1, attackT / ATTACK_DUR), e = p * p * (3 - 2 * p);
    H.armR.rotation.x = -2.8 + (2.4) * e;
    if (!swingSent && p >= 0.45) {
      swingSent = true;
      G.emit('swing', { x: P.pos.x, z: P.pos.z, dx: Math.sin(P.heading), dz: Math.cos(P.heading) });
    }
    if (p >= 1) attackT = -1;
  }
  // Блок: поднятый щит
  if (P.blocking) { H.armL.rotation.x = -1.35; shield.visible = true; }
  else shield.visible = false;
  H.head.rotation.x = 0;

  H.group.position.copy(P.pos);
  H.group.position.y += Math.abs(Math.sin(walkPhase * 2)) * 0.04 * walkAmt;
  H.group.rotation.y = P.heading;

  updateCamera(dt);
  updateInteract();
}

function updateCamera(dt) {
  const P = G.player, camera = G.camera;
  const target = new THREE.Vector3(P.pos.x, P.pos.y + 1.55, P.pos.z);
  const cp = Math.cos(cam.pitch);
  _f.set(Math.sin(cam.yaw) * cp, Math.sin(cam.pitch), Math.cos(cam.yaw) * cp);
  // Камера не уходит под землю: подтягиваем ближе к игроку
  let want = cam.dist;
  for (let t = 1; t >= 0.15; t -= 0.1) {
    const x = target.x + _f.x * cam.dist * t, y = target.y + _f.y * cam.dist * t, z = target.z + _f.z * cam.dist * t;
    want = cam.dist * t;
    if (y > world.groundHeight(x, z) + 0.5) break;
  }
  cam.cur += (want - cam.cur) * (1 - Math.exp(-dt * (want < cam.cur ? 25 : 5)));
  camera.position.copy(target).addScaledVector(_f, cam.cur);
  camera.lookAt(target);
}
