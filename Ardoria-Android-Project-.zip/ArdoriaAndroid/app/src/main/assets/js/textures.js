// Процедурные текстуры: всё рисуется на canvas, внешних файлов нет.
import * as THREE from 'three';

function mkRng(seed) {
  let s = seed >>> 0;
  return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; };
}
function mk(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
const hsl = (h, s, l) => `hsl(${Math.round(h)},${Math.round(s)}%,${Math.round(l)}%)`;

function rrect(g, x, y, w, h, r) {
  g.beginPath();
  g.moveTo(x + r, y); g.lineTo(x + w - r, y); g.quadraticCurveTo(x + w, y, x + w, y + r);
  g.lineTo(x + w, y + h - r); g.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  g.lineTo(x + r, y + h); g.quadraticCurveTo(x, y + h, x, y + h - r);
  g.lineTo(x, y + r); g.quadraticCurveTo(x, y, x + r, y); g.closePath();
}
function speckle(g, size, n, colors, r, maxS = 2) {
  for (let i = 0; i < n; i++) {
    g.fillStyle = colors[(r() * colors.length) | 0];
    const s = 1 + r() * maxS;
    g.fillRect(r() * size, r() * size, s, s);
  }
}

const BUILD = {
  // Красный кирпич с раствором
  brick() {
    const s = 128, c = mk(s, s), g = c.getContext('2d'), r = mkRng(11);
    g.fillStyle = '#b4a899'; g.fillRect(0, 0, s, s);
    const rows = 8, rh = s / rows, bw = s / 4;
    for (let row = 0; row < rows; row++) {
      const off = (row % 2) * bw / 2;
      for (let col = -1; col < 5; col++) {
        const x = col * bw + off, y = row * rh;
        g.fillStyle = hsl(6 + r() * 10, 50 + r() * 12, 30 + r() * 12);
        g.fillRect(x + 1.5, y + 1.5, bw - 3, rh - 3);
        g.fillStyle = 'rgba(255,255,255,0.10)'; g.fillRect(x + 1.5, y + 1.5, bw - 3, 2);
        g.fillStyle = 'rgba(0,0,0,0.18)'; g.fillRect(x + 1.5, y + rh - 3.5, bw - 3, 2);
        for (let i = 0; i < 8; i++) {
          g.fillStyle = `rgba(${r() < 0.5 ? '0,0,0' : '255,200,170'},${0.06 + r() * 0.08})`;
          g.fillRect(x + 2 + r() * (bw - 6), y + 2 + r() * (rh - 6), 2, 2);
        }
      }
    }
    return c;
  },

  // Булыжник / каменные плиты
  stone() {
    const s = 128, c = mk(s, s), g = c.getContext('2d'), r = mkRng(23);
    g.fillStyle = '#4f4d4a'; g.fillRect(0, 0, s, s);
    const rows = 4, rh = s / rows;
    for (let row = 0; row < rows; row++) {
      let x = -r() * 20;
      while (x < s) {
        const w = 22 + r() * 20, l = 50 + r() * 22;
        for (const dx of [0, -s]) {
          g.fillStyle = hsl(32, 5, l);
          rrect(g, x + dx + 2, row * rh + 2, w - 4, rh - 4, 6); g.fill();
          g.fillStyle = 'rgba(255,255,255,0.12)'; g.fillRect(x + dx + 5, row * rh + 4, w - 10, 2);
          g.fillStyle = 'rgba(0,0,0,0.15)'; g.fillRect(x + dx + 5, row * rh + rh - 6, w - 10, 2);
        }
        x += w;
      }
    }
    speckle(g, s, 300, ['rgba(0,0,0,0.12)', 'rgba(255,255,255,0.10)'], r, 2);
    return c;
  },

  // Утоптанная земля
  dirt() {
    const s = 128, c = mk(s, s), g = c.getContext('2d'), r = mkRng(31);
    g.fillStyle = hsl(28, 32, 34); g.fillRect(0, 0, s, s);
    speckle(g, s, 1400, ['#6b4d31', '#8a6a45', '#523a24', '#9b7b55'], r, 3);
    for (let i = 0; i < 40; i++) {
      g.fillStyle = `rgba(${(150 + r() * 40) | 0},${(130 + r() * 30) | 0},${(100 + r() * 30) | 0},0.55)`;
      g.beginPath(); g.ellipse(r() * s, r() * s, 1 + r() * 3, 1 + r() * 2, r() * 3, 0, 6.28); g.fill();
    }
    return c;
  },

  // Трава (общая)
  grass() {
    const s = 128, c = mk(s, s), g = c.getContext('2d'), r = mkRng(37);
    g.fillStyle = hsl(100, 40, 33); g.fillRect(0, 0, s, s);
    speckle(g, s, 1800, ['#3f7a2c', '#5a9a3a', '#4c8a33', '#2f6322'], r, 2);
    return c;
  },

  // Деревянные доски
  wood() {
    const s = 128, c = mk(s, s), g = c.getContext('2d'), r = mkRng(47), pw = 32;
    for (let p = 0; p < 4; p++) {
      g.fillStyle = hsl(26 + r() * 6, 42 + r() * 10, 26 + r() * 10); g.fillRect(p * pw, 0, pw, s);
      for (let i = 0; i < 8; i++) {
        const x = p * pw + 3 + r() * (pw - 6);
        g.strokeStyle = `rgba(0,0,0,${0.10 + r() * 0.12})`; g.lineWidth = 1; g.beginPath();
        for (let y = 0; y <= s; y += 8) {
          const xx = x + Math.sin((y / s) * 6.283 * 2 + i) * 1.2;
          if (y === 0) g.moveTo(xx, y); else g.lineTo(xx, y);
        }
        g.stroke();
      }
      g.fillStyle = 'rgba(0,0,0,0.45)'; g.fillRect(p * pw, 0, 1.5, s);
    }
    return c;
  },

  // Вода
  water() {
    const s = 128, c = mk(s, s), g = c.getContext('2d'), r = mkRng(59);
    g.fillStyle = '#2c6aa5'; g.fillRect(0, 0, s, s);
    for (let k = 0; k < 16; k++) {
      const y0 = r() * s;
      g.strokeStyle = `rgba(255,255,255,${0.08 + r() * 0.1})`; g.lineWidth = 1.5; g.beginPath();
      for (let x = 0; x <= s; x += 4) {
        const y = y0 + Math.sin((x / s) * 6.283 * 2 + k) * 3;
        if (x === 0) g.moveTo(x, y); else g.lineTo(x, y);
      }
      g.stroke();
    }
    return c;
  },

  // Черепица
  roof() {
    const s = 128, c = mk(s, s), g = c.getContext('2d'), r = mkRng(53);
    g.fillStyle = '#3a1d14'; g.fillRect(0, 0, s, s);
    const rows = 8, rh = s / rows, tw = 32;
    for (let row = 0; row < rows; row++) {
      const off = (row % 2) * tw / 2;
      for (let col = -1; col < 5; col++) {
        const x = col * tw + off, y = row * rh;
        g.fillStyle = hsl(12 + r() * 8, 55 + r() * 10, 32 + r() * 10);
        rrect(g, x + 1, y, tw - 2, rh + 6, 7); g.fill();
        g.fillStyle = 'rgba(0,0,0,0.22)'; g.fillRect(x + 1, y + rh - 3, tw - 2, 3);
        g.fillStyle = 'rgba(255,220,190,0.10)'; g.fillRect(x + 3, y + 1, tw - 6, 2);
      }
    }
    return c;
  },

  // Мелкая детализация земли (множится на основную текстуру), средняя яркость ~0.66
  detail() {
    const s = 128, c = mk(s, s), g = c.getContext('2d'), r = mkRng(61);
    g.fillStyle = '#a8a8a8'; g.fillRect(0, 0, s, s);
    for (let i = 0; i < 3500; i++) {
      const v = 135 + ((r() * 70) | 0);
      g.fillStyle = `rgb(${v},${v},${v})`;
      g.fillRect(r() * s, r() * s, 1 + r() * 2, 1 + r() * 2);
    }
    return c;
  },

  // Пучок травы с прозрачностью
  tuft() {
    const s = 64, c = mk(s, s), g = c.getContext('2d'), r = mkRng(67);
    for (let i = 0; i < 14; i++) {
      const x0 = 4 + r() * 56, h = 26 + r() * 34;
      g.fillStyle = hsl(85 + r() * 35, 55, 26 + r() * 22);
      g.beginPath(); g.moveTo(x0 - 3, s); g.lineTo(x0 + (r() - 0.5) * 12, s - h); g.lineTo(x0 + 3, s); g.fill();
    }
    return c;
  },

  // Хвоя ели
  foliage() {
    const s = 64, c = mk(s, s), g = c.getContext('2d'), r = mkRng(71);
    g.fillStyle = '#3b7a46'; g.fillRect(0, 0, s, s);
    speckle(g, s, 500, ['#2d6338', '#4a8c55', '#27562f'], r, 2);
    for (let i = 0; i < 20; i++) { g.fillStyle = 'rgba(0,0,0,0.12)'; g.fillRect(0, r() * s, s, 1); }
    return c;
  },

  // Листва дуба
  leaf() {
    const s = 64, c = mk(s, s), g = c.getContext('2d'), r = mkRng(73);
    g.fillStyle = '#5a9a3a'; g.fillRect(0, 0, s, s);
    speckle(g, s, 600, ['#4a8a2e', '#6aac45', '#3e7a26'], r, 3);
    return c;
  }
};

const canvases = {};
export function canvasOf(name) {
  if (!canvases[name]) canvases[name] = BUILD[name]();
  return canvases[name];
}

const bases = {}, cache = new Map();
// Текстура по имени с нужным повтором (клоны кэшируются)
export function tex(name, rx = 1, ry = 1) {
  const key = name + '|' + rx + '|' + ry;
  if (cache.has(key)) return cache.get(key);
  let base = bases[name];
  if (!base) {
    base = new THREE.CanvasTexture(canvasOf(name));
    base.colorSpace = THREE.SRGBColorSpace;
    base.wrapS = base.wrapT = THREE.RepeatWrapping;
    base.anisotropy = 4;
    bases[name] = base;
  }
  let t = base;
  if (rx !== 1 || ry !== 1) {
    t = base.clone();
    t.repeat.set(rx, ry);
    t.needsUpdate = true;
  }
  cache.set(key, t);
  return t;
}
